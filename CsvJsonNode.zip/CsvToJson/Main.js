const csvjson = require('csvjson');
const readFile = require('fs').readFile;
const moment = require('moment');
var fs = require('fs');

console.log('Iniciando leitura: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"))
const inicio = new Date().getTime();

readFile('./brasil.csv', 'utf-8', (err, fileContent) => {
    if (err) {
        console.log(err);
        throw new Error(err);
    }

    console.log('Leitura finalizada: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"))

    const total = new Date().getTime() - inicio
    console.log('Tempo de leitura: ' + total + ' ms')

    ConvertCsvToJson(fileContent)
    .then(result => {
        WriteJson(result)
        .then(result => {console.log(result); })
        .catch(error => console.log("Erro ao escrever Json: " + error));
    })
    .catch(error => console.log("Erro ao converter Json: " + error));
});

function ConvertCsvToJson(fileContent) {
    const promise = new Promise( (resolve, reject) => { 
        try {
            console.log('Convertendo arquivo: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"))
            const inicioConversao = new Date().getTime()
            let data = JSON.stringify(csvjson.toObject(fileContent));    
            console.log('Arquivo convertido: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"))
            const totalConvert = new Date().getTime() - inicioConversao
            console.log('Tempo total de conversão: ' + totalConvert + ' ms')
            resolve(data);
        }
        catch (error) {
            reject(error);
        }
    });
    return promise;
}

function WriteJson(data) {
    const promise = new Promise( (resolve, reject) => { 
                try {
                    console.log('Escrevendo arquivo: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"))
                    const inicioEscrita = new Date().getTime()
                    fs.writeFileSync('arquivo.json', data);  
                    console.log('Arquivo criado: ' + moment().format("YYYY-MM-DD HH:mm:ss.SSS"));
                    const totalEscrita = new Date().getTime() - inicioEscrita
                    console.log('Tempo de criação: ' + totalEscrita + ' ms')
                } catch (error) {
                    reject(error);
                    }
                });
    return promise;
}